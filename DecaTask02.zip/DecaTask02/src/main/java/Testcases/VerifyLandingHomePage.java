package Testcases;

import org.testng.annotations.Test;

import Pages.CustomerCreatePage;

public class VerifyLandingHomePage {

	@Test

	public void landingHomePageValidation() {

		CustomerCreatePage obj1 = new CustomerCreatePage();

		obj1.verifyHeaderTextlandingHomePage();
		obj1.verifytActionMenuSelection();
		obj1.verifySignOutSelection();

	}

}
