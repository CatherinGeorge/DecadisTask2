package Testcases;

import Baseclass.Base1;
import Pages.CustomerCreatePage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyCreateAccPage extends Base1 {

	@Test

	public void createNewAccountPageValidation() {

		CustomerCreatePage obj = new CustomerCreatePage();

		obj.initialize();
		obj.navigateToCreatePage();
		obj.getTitleVerify();
		obj.enterFirstName();
		obj.entertLastName();
		obj.verifyLetterCheckboxSelection();
		obj.enterEmail();
		obj.enetrPassWord();
		obj.enterConfirmPassWord();
		obj.verifygetTextCreateAccButton();
		obj.clickCreateAccButtonSelection();
	}

}
