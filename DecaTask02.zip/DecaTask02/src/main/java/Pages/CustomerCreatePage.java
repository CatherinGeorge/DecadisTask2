package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import Baseclass.Base1;
import org.testng.asserts.Assertion;
import org.testng.Assert;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

public class CustomerCreatePage extends Base1 {

	public void navigateToCreatePage() {
		getDriver().navigate().to("https://magento.softwaretestingboard.com/customer/account/create/");

	}

	
	public void getTitleVerify() {
		String actualTitle = getDriver().getTitle();
		String expectedTitle = "Create New Customer Account Magento Commerce - website to practice selenium | demo website for automation testing | selenium practice sites";
		Assert.assertEquals(expectedTitle, actualTitle);
		System.out.println("TitlePage Assert - passed");

	}

	public void enterFirstName() {
		WebElement firstName = getDriver().findElement(By.xpath("//input[@class='input-text required-entry']"));
		firstName.sendKeys("Test11");

	}

	public void entertLastName() {
		WebElement lastName = getDriver().findElement(By.xpath("(//input[@class='input-text required-entry'])[2]"));
		lastName.sendKeys("Task11");
	}

	public void verifyLetterCheckboxSelection() {
		WebElement newsLetterCheckbox = getDriver().findElement(By.xpath("//input[@type='checkbox']"));
		newsLetterCheckbox.click();
		Assert.assertEquals(true, newsLetterCheckbox.isSelected()); // Verifies that the checkbox is selected after action
		System.out.println("NewsLetter Checkbox is selected – Assert passed");

	}

	public void enterEmail() {
		WebElement email = getDriver().findElement(By.xpath("//input[@title='Email']"));
		email.sendKeys("Test_Task11@example.com");

	}

	public void enetrPassWord() {
		WebElement passWord = getDriver().findElement(By.xpath("//input[@title='Password']"));
		passWord.sendKeys("Test11@123");

	}

	public void enterConfirmPassWord() {
		WebElement confirmPassWord = getDriver().findElement(By.xpath("//input[@title='Confirm Password']"));
		confirmPassWord.sendKeys("Test11@123");

	}

	public void verifygetTextCreateAccButton() {

		WebElement e = getDriver().findElement(By.xpath("//button[@title='Create an Account']//span[1]"));
		String actualElementText = e.getText();
		String expectedElementText = "Create an Account";
		Assert.assertEquals(actualElementText, expectedElementText);
		System.out.println("getText Create an Accout Button - Assert passed");
	}

	public void clickCreateAccButtonSelection() {

		/*WebElement createAccButton = getDriver().findElement(By.xpath("//button[contains(@class,'action submit')]"));
		createAccButton.click();
		Assert.assertEquals(false, createAccButton.isSelected()); // Verifies that the button is selected after action
		System.out.println("Create Button is selected – Assert passed");
		*/
		try{
			WebElement createAccButton = getDriver().findElement(By.xpath("//button[contains(@class,'action submit')]"));
			createAccButton.click();
	      }
	      catch(StaleElementReferenceException e){
	    	  WebElement createAccButton = getDriver().findElement(By.xpath("//button[contains(@class,'action submit')]"));
	    	  createAccButton.click();
	  	      }
		System.out.println("Create Account button is selected – passed");
	}

	public void verifyHeaderTextlandingHomePage() {
		String landingPageHeaderText = getDriver().findElement(By.xpath("//h1[@class='page-title']")).getText();

		if (landingPageHeaderText.contains("My Account")) {
			System.out.println("Header text validation, Landing Homepage Page - " + "Passed");
		} else {
			System.out.println("Header text validation, Landing Homepage Page - " + "Failed");
		}
	}

	public void verifytActionMenuSelection() {
		WebElement selectActionButton = getDriver().findElement(By.xpath("(//button[@class='action switch'])[1]"));
		selectActionButton.click();
		Assert.assertEquals(false, selectActionButton.isSelected()); // Verifies that the button is selected after action
		System.out.println("Action Menu is selected – Assert passed");
	}

	public void verifySignOutSelection() {
		WebElement selectSignOut = getDriver().findElement(By.xpath("//li[@class='authorization-link']//a"));
		Actions action = new Actions(getDriver());
		action.moveToElement(selectSignOut).click().perform();
		System.out.println("SignOut button is selected – passed");
	}

}
